# Auth And Env

## Browser OAuth

交互式终端优先使用浏览器 OAuth：

```bash
export WORKCTL_AUTH_CLIENT_ID=<client-id>
export WORKCTL_AUTH_CLIENT_SECRET=<client-secret>
export WORKCTL_AUTH_AUTHORIZE_URL=https://auth.example.com/oauth/authorize
export WORKCTL_AUTH_TOKEN_URL=https://auth.example.com/oauth/token

workctl auth login
workctl auth status --format json
```

等价显式入口：

```bash
workctl auth login --browser
```

## Device Flow

无浏览器或远程终端使用 device flow：

```bash
export WORKCTL_AUTH_CLIENT_ID=<client-id>
export WORKCTL_AUTH_CLIENT_SECRET=<client-secret>
export WORKCTL_AUTH_TOKEN_URL=https://auth.example.com/oauth/token
export WORKCTL_AUTH_DEVICE_CODE_URL=https://auth.example.com/oauth/device/code
export WORKCTL_AUTH_DEVICE_TOKEN_URL=https://auth.example.com/oauth/device/token

workctl auth login --device
workctl auth refresh
```

## Token 兼容入口

临时 token 或自动化场景：

```bash
workctl auth login --token <token>
printf '%s' "$WORKCTL_TOKEN" | workctl auth login --token-stdin
workctl auth status --format json
```

`WORKCTL_TOKEN` 只覆盖当前进程，不会自动写回本地持久化鉴权状态。

## Auth 生命周期

```bash
workctl auth status --format json
workctl auth refresh
workctl auth reset
workctl auth logout
```

持久化凭证使用平台安全存储：

- macOS：随机 DEK 存 Keychain，加密 token data 存本地 `.data`。
- Windows：DPAPI 保护的 secret material 存当前用户 registry hive。
- Linux：本地 DEK 文件加密 token data。

## Runtime 变量

常规用户通常只需要：

- `WORKCTL_AUTH_CLIENT_ID`
- `WORKCTL_AUTH_CLIENT_SECRET`
- `WORKCTL_AUTH_AUTHORIZE_URL`
- `WORKCTL_AUTH_TOKEN_URL`
- `WORKCTL_AUTH_DEVICE_CODE_URL`
- `WORKCTL_AUTH_DEVICE_TOKEN_URL`
- `WORKCTL_AUTH_SCOPES`，可选
- `WORKCTL_CONFIG_DIR`，可选
- `WORKCTL_TOKEN`，仅特殊自动化场景

源码或原始二进制调试可用：

- `WORKCTL_MCP_URL`
- `WORKCTL_RUNTIME_CONFIG`
- `WORKCTL_DEBUG_TOKEN`
- `WORKCTL_CATALOG_FIXTURE`

npm 包会忽略 `WORKCTL_MCP_URL`、外部 `WORKCTL_RUNTIME_CONFIG`、`WORKCTL_CATALOG_FIXTURE`，使用二进制内置 discovery URL。

## Trace And Audit

平台集成方可以注入：

- `WORKCTL_TRACE_ID`：转发为 `X-Trace-Id`。
- `WORKCTL_MESSAGE_ID`：`WORKCTL_TRACE_ID` 的 legacy fallback。
- `WORKCTL_SOURCE`：转发为 `X-Source`，默认 `cli`。
- `WORKCTL_METADATA`：JSON 字符串，转发为 `X-Metadata`。

`WORKCTL_METADATA` 必须是合法 JSON；非法值会被忽略。普通 CLI 用户通常不需要设置这些变量。
