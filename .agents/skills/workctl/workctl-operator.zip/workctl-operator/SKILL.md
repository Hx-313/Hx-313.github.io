---
name: workctl-operator
description: 安装、升级、认证、发现并使用 Work Agent CLI (`workctl`)；适用于指导用户配置 workctl、执行动态业务命令、排查 auth/cache/schema/runtime 问题，或为业务域接入 workctl registry 协议。
metadata:
  short-description: Install and use workctl
---

# Workctl Operator

使用 `workctl` 管理 Work Agent 平台能力。优先通过 CLI 和结构化输出完成任务；只有在做业务域接入、协议联调或排查 registry 服务时，才直接查看 HTTP 协议细节。

## 先读哪个 reference

- 安装、升级、首次就绪检查：读 [install-and-bootstrap.md](references/install-and-bootstrap.md)。
- 登录、token、配置目录、trace/audit 环境变量：读 [auth-and-env.md](references/auth-and-env.md)。
- 查询可用命令、查看参数、执行动态命令、解析输出：读 [schema-and-dynamic-commands.md](references/schema-and-dynamic-commands.md)。
- 业务域工具编排、跨工具组合、当前 Alibaba seller-assistant 场景迁移：先读 [business-tool-composition.md](references/business-tool-composition.md)，再按业务读取下方专门 reference。
- 新业务域接入 discovery/detail/tools/call：读 [registry-domain-onboarding.md](references/registry-domain-onboarding.md)。
- 报错、缓存、恢复流程、exit code：读 [recovery-and-troubleshooting.md](references/recovery-and-troubleshooting.md)。

## 业务 reference 路由

- 店铺经营、数据分析、员工/商品/访客下钻：读 [business-data-analysis.md](references/business-data-analysis.md)。
- 广告诊断、广告报表、品牌广告关键词、加品删品：读 [business-ads-marketing.md](references/business-ads-marketing.md)。
- 商品发布、商品查询、商品信息优化、批量编辑：读 [business-product-publish.md](references/business-product-publish.md)。
- 图片/视频生成、店铺装修、网站创建/编辑/发布：读 [business-creative-storefront.md](references/business-creative-storefront.md)。
- 热品洞察、蓝海机会、1688/供应商/分销找品：读 [business-market-sourcing.md](references/business-market-sourcing.md)。
- 物流运费、关税、交易、拒付、店铺/商品风险：读 [business-logistics-trade-risk.md](references/business-logistics-trade-risk.md)。
- IM 会话、客服诊断、买家回复、知识问答、深度研究：读 [business-communication-knowledge.md](references/business-communication-knowledge.md)。
- 想评估哪些通用能力应沉淀进 CLI：读 [business-cli-roadmap.md](references/business-cli-roadmap.md)。

## 基本工作流

1. 确认 `workctl` 可用：
   ```bash
   workctl version --format json
   ```
2. 确认认证状态：
   ```bash
   workctl auth status --format json
   ```
3. 确认可发现命令：
   ```bash
   workctl schema --format json
   ```
4. 执行业务命令前，先查看目标命令 schema；参数、字段、异步、分页和写操作标记以 schema/help 为准：
   ```bash
   workctl schema <command.group.action> --format json
   ```
5. 执行时默认使用机器可读输出：
   ```bash
   workctl <command> <group> <action> --format json
   ```

## 操作原则

- 不要猜命令路径、参数名、字段名；先用 `workctl schema ... --format json` 确认。
- 从旧 skill 或旧 MCP/CLI 文档迁移业务流程时，只迁移“意图路由、ID 接力、时间预检、分页、轮询、确认、输出校验”等工具组合模式；具体命令、flag、字段必须重新查 `workctl schema` / `--help`。
- Agent 场景默认加 `--format json`；需要抽字段时用 `--jq` 或 `--fields`。
- 默认 JSON 输出尽量极简：对象型业务结果会平铺到顶层，数组/字符串结果才放在 `data`；失败优先读 `error.reason/error.next_action`。
- 动态命令的业务字段可能叫 `model/items/result/records` 等，不要假设一定有 `.data`；先读顶层字段，没有再读 `.data.*`。
- `--output` 表示保存完整结果文件，通常会保留 `meta` 和完整 envelope；如果只想保存某个字段，用 `--jq '<expr>' --output result.json`，如果想保存默认极简输出，用 shell 重定向 `> result.json`。
- 写入、发送、删除、授权变更等高影响操作，先向用户展示操作摘要并取得明确确认。
- 如果 schema 标记 `requires_yes` / `mutating`，按高影响操作处理；不要只凭命令名判断是否安全。
- 如果 schema 标记支持 dry-run，先用业务命令的 `--dry-run --format json` 预览。
- 长任务优先使用 schema 暴露的异步/轮询提示；提交后保留 `batch_id` / `taskId`，必要时用 `workctl task status|wait` 或业务查询命令恢复。
- 当前官方安装面是 npm；不要把本地 `auto_cli` provider 当作当前运行时模型。
- npm 包使用内置 discovery URL，忽略外部 `WORKCTL_MCP_URL`、`WORKCTL_RUNTIME_CONFIG`、`WORKCTL_CATALOG_FIXTURE`；这些只适合源码或原始二进制调试。

## 本仓库权威文档

当前行为以 `raw/cli/README.md`、`raw/cli/docs/reference.md`、`raw/cli/docs/environment-variables.md`、`raw/cli/docs/registry/README.md` 和代码为准。历史设计稿、旧 provider 文档、旧包名或旧鉴权参数不要作为现行契约。
